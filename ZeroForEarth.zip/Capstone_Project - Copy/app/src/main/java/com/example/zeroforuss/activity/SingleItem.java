package com.example.zeroforuss.activity;

public class SingleItem {
    public String name;
    public String description;
    public int resId;

    public SingleItem(String name, String description, int resId){
        this.name = name;
        this.description = description;
        this.resId = resId;
    }
}

